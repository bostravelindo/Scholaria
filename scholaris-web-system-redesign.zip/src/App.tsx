import { useEffect, useRef, useState } from 'react';

// ── Constants ────────────────────────────────────────────
const GAS_URL = 'https://script.google.com/macros/s/AKfycbxIv_0lxEf8qFq9Jdi3Bs2PsFaH8K0K5u4H3tLMIHsNgJSPNmRREFPrMuaHd0cJWDPt/exec';

const AI_MODELS = [
  { value: 'gemini-2.5-pro-preview-06-05', label: '🧠 Gemini 3.1 Pro Preview ✨' },
  { value: 'claude-sonnet-4-6', label: '🎭 Claude Sonnet 4.6 Extended ✨' },
  { value: 'gpt-4o-mini-high', label: '🤖 ChatGPT o4-mini High ✨' },
  { value: 'deepseek-r1', label: '🔬 DeepSeek R1' },
  { value: 'llama-4-maverick', label: '🦙 Llama 4 Maverick' },
  { value: 'grok-4-20', label: '⚡ Grok 4.20 ✨' },
  { value: 'dual-ai', label: '🚀 Dual-AI Pipeline (Gemini + Claude)' },
];

const WRITE_MODES = [
  { value: 'segmented-article', label: '★ Artikel Ilmiah Lengkap (Segmented)' },
  { value: 'segmented-proposal', label: '★ Proposal Penelitian (Segmented)' },
  { value: 'segmented-thesis', label: '★ Tesis/Disertasi BAB I–V (Segmented)' },
  { value: 'segmented-slr', label: '★ SLR / Systematic Review (Segmented)' },
  { value: 'article', label: 'Artikel Ilmiah' },
  { value: 'abstract', label: 'Abstrak' },
  { value: 'introduction', label: 'Pendahuluan' },
  { value: 'literature', label: 'Tinjauan Pustaka' },
  { value: 'methodology', label: 'Metodologi' },
  { value: 'discussion', label: 'Hasil & Pembahasan' },
  { value: 'conclusion', label: 'Kesimpulan' },
  { value: 'proposal', label: 'Proposal Penelitian' },
  { value: 'book-chapter', label: 'Bab Buku / Monograf' },
];

const CITATION_STYLES = [
  { value: 'apa7', label: 'APA 7' },
  { value: 'chicago-footnote', label: 'Chicago 17 Footnote' },
  { value: 'chicago-author-date', label: 'Chicago 17 Author-Date' },
  { value: 'harvard', label: 'Harvard' },
  { value: 'ieee', label: 'IEEE' },
  { value: 'turabian', label: 'Turabian 9th' },
  { value: 'isnad', label: 'ISNAD (إسناد)' },
];

const LANGUAGES = [
  { value: 'id', label: 'Bahasa Indonesia' },
  { value: 'en', label: 'English' },
  { value: 'ar', label: 'العربية' },
];

const PARA_MODES = [
  { value: 'paraphrase', label: '🔄 Parafrase', icon: '🔄' },
  { value: 'humanize', label: '🧑 Humanize', icon: '🧑' },
  { value: 'formalize', label: '📐 Formalize', icon: '📐' },
  { value: 'elaborate', label: '📈 Elaborate', icon: '📈' },
  { value: 'condense', label: '🗜️ Kondensasi', icon: '🗜️' },
  { value: 'translate', label: '🌐 Terjemahan', icon: '🌐' },
];

const REVIEW_ASPECTS = [
  { value: 'comprehensive', label: 'Komprehensif (Semua Aspek)' },
  { value: 'structure', label: 'Struktur & Organisasi' },
  { value: 'methodology', label: 'Metodologi' },
  { value: 'citation', label: 'Sitasi & Referensi' },
  { value: 'argumentation', label: 'Argumentasi & Logika' },
  { value: 'language', label: 'Bahasa & Gaya Penulisan' },
];

const DB_SOURCES = [
  { id: 'crossref', label: 'CrossRef', color: '#3b82f6', active: true },
  { id: 'doaj', label: 'DOAJ', color: '#10b981', active: true },
  { id: 'europmc', label: 'Europe PMC', color: '#8b5cf6', active: true },
  { id: 'openalex', label: 'OpenAlex', color: '#f59e0b', active: true },
  { id: 'scopus', label: '🟠 Scopus', color: '#ef4444', active: true },
  { id: 'semantic', label: 'Semantic Scholar', color: '#06b6d4', active: true },
];

// ── Utility Functions ────────────────────────────────────
function wordCount(text: string) {
  return text.trim() ? text.trim().split(/\s+/).length : 0;
}

function formatDate(d = new Date()) {
  return d.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function formatClock() {
  return new Date().toLocaleTimeString('id-ID');
}

async function callGAS(payload: Record<string, unknown>) {
  const res = await fetch(GAS_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`GAS Error: ${res.status}`);
  return res.json();
}

// ── Types ────────────────────────────────────────────────
interface User {
  email: string;
  name: string;
  role: string;
  expiry?: string;
}

interface RefItem {
  title: string;
  authors: string;
  year: number | string;
  journal: string;
  doi: string;
  citations?: number;
  openAccess?: boolean;
  scopusIndexed?: boolean;
  source?: string;
  abstract?: string;
  url?: string;
}

interface HistoryDoc {
  id: string;
  title: string;
  mode: string;
  model: string;
  date: string;
  words: number;
  content: string;
}

// ── Main Component ───────────────────────────────────────
export default function App() {
  const [page, setPage] = useState<string>('landing');
  const [user, setUser] = useState<User | null>(null);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [showAuth, setShowAuth] = useState(false);
  const [clock, setClock] = useState(formatClock());
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notification, setNotification] = useState<{ msg: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [stats, setStats] = useState({ words: 0, refs: 0, sessions: 0 });
  const [biblio, setBiblio] = useState<RefItem[]>([]);
  const [history, setHistory] = useState<HistoryDoc[]>([]);
  const mainRef = useRef<HTMLDivElement>(null);

  // ── Clock ──
  useEffect(() => {
    const t = setInterval(() => setClock(formatClock()), 1000);
    return () => clearInterval(t);
  }, []);

  // ── Restore session ──
  useEffect(() => {
    const saved = localStorage.getItem('scholaris_user');
    if (saved) { setUser(JSON.parse(saved)); setPage('writer'); }
    const s = localStorage.getItem('scholaris_stats');
    if (s) setStats(JSON.parse(s));
    const b = localStorage.getItem('scholaris_biblio');
    if (b) setBiblio(JSON.parse(b));
    const h = localStorage.getItem('scholaris_history');
    if (h) setHistory(JSON.parse(h));
  }, []);

  function notify(msg: string, type: 'success' | 'error' | 'info' = 'info') {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 4000);
  }

  function logout() {
    localStorage.removeItem('scholaris_user');
    setUser(null); setPage('landing'); setSidebarOpen(false);
    notify('Berhasil logout.', 'success');
  }

  function navigate(p: string) {
    if (p !== 'landing' && !user) { setShowAuth(true); return; }
    setPage(p); setSidebarOpen(false);
    mainRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function saveStats(s: typeof stats) {
    setStats(s); localStorage.setItem('scholaris_stats', JSON.stringify(s));
  }

  function addToBiblio(ref: RefItem) {
    const exists = biblio.find(b => b.doi === ref.doi);
    if (exists) { notify('Referensi sudah ada di daftar pustaka.', 'info'); return; }
    const nb = [...biblio, ref];
    setBiblio(nb); localStorage.setItem('scholaris_biblio', JSON.stringify(nb));
    notify('✅ Referensi ditambahkan ke Bibliografi.', 'success');
  }

  function saveHistory(doc: HistoryDoc) {
    const nh = [doc, ...history.slice(0, 29)];
    setHistory(nh); localStorage.setItem('scholaris_history', JSON.stringify(nh));
  }

  const navItems = [
    { id: 'writer', icon: '⚡', label: 'AI Writer' },
    { id: 'multiwriter', icon: '💬', label: 'Multi-Turn' },
    { id: 'references', icon: '🔍', label: 'Referensi' },
    { id: 'paraphrase', icon: '✍️', label: 'Paraphraser' },
    { id: 'reviewer', icon: '🎓', label: 'Reviewer' },
    { id: 'converter', icon: '📄', label: 'Converter' },
    { id: 'bibliography', icon: '📚', label: 'Bibliografi' },
    { id: 'history', icon: '💾', label: 'Riwayat' },
    { id: 'tips', icon: '💡', label: 'Tips' },
  ];

  return (
    <div className="app-root">
      {/* ── Notification Toast ── */}
      {notification && (
        <div className={`toast toast-${notification.type}`}>
          {notification.msg}
        </div>
      )}

      {/* ── Auth Modal ── */}
      {showAuth && (
        <AuthModal
          mode={authMode}
          setMode={setAuthMode}
          onClose={() => setShowAuth(false)}
          onSuccess={(u) => {
            setUser(u);
            localStorage.setItem('scholaris_user', JSON.stringify(u));
            setShowAuth(false);
            setPage('writer');
            const ns = { ...stats, sessions: stats.sessions + 1 };
            saveStats(ns);
            notify(`🎉 Selamat datang, ${u.name}!`, 'success');
          }}
          notify={notify}
        />
      )}

      {/* ── Sidebar ── */}
      {user && (
        <>
          <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
            <div className="sidebar-logo">
              <span className="logo-icon">✦</span>
              <span className="logo-text">SCHOLARIS</span>
              <span className="logo-version">v10.1</span>
            </div>

            <div className="sidebar-user">
              <div className="user-avatar">{user.name.charAt(0).toUpperCase()}</div>
              <div className="user-info">
                <p className="user-name">{user.name}</p>
                <p className="user-email">{user.email}</p>
                <span className={`user-badge ${user.role === 'premium' ? 'badge-premium' : 'badge-free'}`}>
                  {user.role === 'premium' ? '💎 Premium' : '🔓 Free'}
                </span>
              </div>
            </div>

            <nav className="sidebar-nav">
              {navItems.map(item => (
                <button
                  key={item.id}
                  className={`nav-item ${page === item.id ? 'nav-active' : ''}`}
                  onClick={() => navigate(item.id)}
                >
                  <span className="nav-icon">{item.icon}</span>
                  <span className="nav-label">{item.label}</span>
                  {item.id === 'bibliography' && biblio.length > 0 && (
                    <span className="nav-badge">{biblio.length}</span>
                  )}
                </button>
              ))}
            </nav>

            <div className="sidebar-stats">
              <div className="stat-item">
                <span className="stat-num">{stats.words.toLocaleString()}</span>
                <span className="stat-label">Kata</span>
              </div>
              <div className="stat-item">
                <span className="stat-num">{stats.refs}</span>
                <span className="stat-label">Refs</span>
              </div>
              <div className="stat-item">
                <span className="stat-num">{stats.sessions}</span>
                <span className="stat-label">Sesi</span>
              </div>
            </div>

            <div className="sidebar-footer">
              <span className="clock-display">🕐 {clock}</span>
              <button className="btn-logout" onClick={logout}>Logout</button>
            </div>
          </aside>
          {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)} />}
        </>
      )}

      {/* ── Top Bar ── */}
      <header className={`topbar ${user ? 'topbar-app' : 'topbar-landing'}`}>
        <div className="topbar-left">
          {user && (
            <button className="menu-btn" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <span /><span /><span />
            </button>
          )}
          <div className="topbar-brand" onClick={() => navigate(user ? 'writer' : 'landing')}>
            <span className="brand-icon">✦</span>
            <span className="brand-name">SCHOLARIS</span>
            <span className="brand-ver">v10.1</span>
          </div>
        </div>
        <div className="topbar-right">
          {!user ? (
            <>
              <button className="btn-ghost" onClick={() => { setAuthMode('login'); setShowAuth(true); }}>Login</button>
              <button className="btn-primary" onClick={() => { setAuthMode('register'); setShowAuth(true); }}>Daftar</button>
            </>
          ) : (
            <div className="topbar-user">
              <span className="topbar-clock">{clock}</span>
              <span className="topbar-username">👤 {user.name}</span>
            </div>
          )}
        </div>
      </header>

      {/* ── Main Content ── */}
      <main className={`main-content ${user ? 'main-with-sidebar' : ''}`} ref={mainRef}>
        {page === 'landing' && <LandingPage onAuth={(m) => { setAuthMode(m); setShowAuth(true); }} />}
        {page === 'writer' && user && (
          <WriterPage user={user} stats={stats} saveStats={saveStats}
            biblio={biblio} addToBiblio={addToBiblio}
            saveHistory={saveHistory} notify={notify} />
        )}
        {page === 'multiwriter' && user && (
          <MultiWriterPage user={user} stats={stats} saveStats={saveStats}
            saveHistory={saveHistory} notify={notify} />
        )}
        {page === 'references' && user && (
          <ReferencesPage biblio={biblio} addToBiblio={addToBiblio} notify={notify} />
        )}
        {page === 'paraphrase' && user && (
          <ParaphrasePage notify={notify} stats={stats} saveStats={saveStats} />
        )}
        {page === 'reviewer' && user && (
          <ReviewerPage notify={notify} />
        )}
        {page === 'converter' && user && (
          <ConverterPage biblio={biblio} addToBiblio={addToBiblio}
            saveHistory={saveHistory} notify={notify} stats={stats} saveStats={saveStats} />
        )}
        {page === 'bibliography' && user && (
          <BibliographyPage biblio={biblio} setBiblio={(b) => {
            setBiblio(b); localStorage.setItem('scholaris_biblio', JSON.stringify(b));
          }} notify={notify} />
        )}
        {page === 'history' && user && (
          <HistoryPage history={history} setHistory={(h) => {
            setHistory(h); localStorage.setItem('scholaris_history', JSON.stringify(h));
          }} notify={notify} />
        )}
        {page === 'tips' && <TipsPage stats={stats} clock={clock} />}
      </main>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── AUTH MODAL ───────────────────────────────────────────
// ════════════════════════════════════════════════════════
function AuthModal({ mode, setMode, onClose, onSuccess, notify }: {
  mode: 'login' | 'register';
  setMode: (m: 'login' | 'register') => void;
  onClose: () => void;
  onSuccess: (u: User) => void;
  notify: (m: string, t: 'success' | 'error' | 'info') => void;
}) {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '', institution: '', phone: '' });

  function upd(k: string, v: string) { setForm(p => ({ ...p, [k]: v })); }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (mode === 'register' && form.password !== form.confirm) {
      notify('Password tidak cocok.', 'error'); return;
    }
    setLoading(true);
    try {
      const payload = mode === 'login'
        ? { action: 'login', email: form.email, password: form.password }
        : { action: 'register', name: form.name, email: form.email, password: form.password, institution: form.institution, phone: form.phone };
      const res = await callGAS(payload);
      if (res.success) {
        onSuccess({ email: res.email || form.email, name: res.name || form.name, role: res.role || 'free', expiry: res.expiry });
      } else {
        notify(res.message || 'Terjadi kesalahan.', 'error');
      }
    } catch {
      notify('Koneksi gagal. Coba lagi.', 'error');
    }
    setLoading(false);
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>
        <div className="modal-header">
          <span className="modal-icon">✦</span>
          <h2>{mode === 'login' ? 'Login ke SCHOLARIS' : 'Daftar Akun Baru'}</h2>
          <p>{mode === 'login' ? 'Masukkan email dan password Anda.' : 'Isi formulir untuk membuat akun.'}</p>
        </div>
        <form onSubmit={handleSubmit} className="auth-form">
          {mode === 'register' && (
            <>
              <div className="form-group">
                <label>Nama Lengkap</label>
                <input required placeholder="Dr. Nama Anda" value={form.name} onChange={e => upd('name', e.target.value)} />
              </div>
              <div className="form-group">
                <label>Institusi</label>
                <input placeholder="Universitas / Lembaga" value={form.institution} onChange={e => upd('institution', e.target.value)} />
              </div>
              <div className="form-group">
                <label>No. WhatsApp</label>
                <input placeholder="08xxxxxxxxxx" value={form.phone} onChange={e => upd('phone', e.target.value)} />
              </div>
            </>
          )}
          <div className="form-group">
            <label>Email</label>
            <input required type="email" placeholder="email@contoh.com" value={form.email} onChange={e => upd('email', e.target.value)} />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input required type="password" placeholder="••••••••" value={form.password} onChange={e => upd('password', e.target.value)} />
          </div>
          {mode === 'register' && (
            <div className="form-group">
              <label>Konfirmasi Password</label>
              <input required type="password" placeholder="••••••••" value={form.confirm} onChange={e => upd('confirm', e.target.value)} />
            </div>
          )}
          <button type="submit" className="btn-primary btn-full" disabled={loading}>
            {loading ? <span className="spinner" /> : (mode === 'login' ? '🔓 Login' : '📝 Daftar Sekarang')}
          </button>
        </form>
        <div className="auth-switch">
          {mode === 'login' ? (
            <p>Belum punya akun? <button onClick={() => setMode('register')}>Daftar di sini</button></p>
          ) : (
            <p>Sudah punya akun? <button onClick={() => setMode('login')}>Login</button></p>
          )}
        </div>
        {mode === 'register' && (
          <div className="auth-note">
            <p>💡 Setelah daftar, transfer <strong>Rp 100.000</strong> ke BSI <strong>7108946096</strong> a.n. Iskandar, lalu kirim bukti ke WA <strong>081250955443</strong>.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── LANDING PAGE ─────────────────────────────────────────
// ════════════════════════════════════════════════════════
function LandingPage({ onAuth }: { onAuth: (m: 'login' | 'register') => void }) {
  return (
    <div className="landing">
      {/* Hero */}
      <section className="hero">
        <div className="hero-bg" />
        <div className="hero-content">
          <div className="hero-badge">✦ Platform Akademik Bertenaga AI</div>
          <h1 className="hero-title">
            <span className="gradient-text">SCHOLARIS</span>
            <br />AI Academic Writer Engine
          </h1>
          <p className="hero-subtitle">
            Hasilkan tulisan akademis berkualitas jurnal Q1/Q2 menggunakan kecerdasan <strong>Dual-AI (Gemini 3.1 Pro + Claude Sonnet)</strong> yang canggih. Dilengkapi referensi Hexa-Source, paraphraser, reviewer, dan banyak lagi.
          </p>
          <div className="hero-actions">
            <button className="btn-hero-primary" onClick={() => onAuth('register')}>🚀 Mulai Gratis</button>
            <button className="btn-hero-ghost" onClick={() => onAuth('login')}>🔓 Login</button>
          </div>
          <div className="hero-stats">
            {[['8+','Fitur Unggulan'],['6','Model AI Premium'],['13','Mode Penulisan'],['∞','Referensi CrossRef']].map(([n,l]) => (
              <div key={l} className="hero-stat">
                <span className="hero-stat-num">{n}</span>
                <span className="hero-stat-label">{l}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="hero-visual">
          <div className="ai-orb">
            <div className="orb-ring ring1" />
            <div className="orb-ring ring2" />
            <div className="orb-ring ring3" />
            <div className="orb-core">
              <span>AI</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section">
        <div className="section-header">
          <h2>✨ Semua Fitur Dalam Satu Platform</h2>
          <p>Ekosistem lengkap untuk penulisan akademis profesional</p>
        </div>
        <div className="features-grid">
          {[
            { icon:'⚡', title:'AI Writer — Dual-AI Pipeline', desc:'Generate artikel ilmiah, proposal, SLR, hingga bab tesis menggunakan Gemini 3.1 Pro Preview + Claude Sonnet 4.6 Extended secara bersamaan.', tags:['Segmented','IMRaD','CrossRef'] },
            { icon:'💬', title:'Multi-Turn Writer', desc:'Dialog interaktif multi-giliran untuk membangun, memperbaiki, dan mengembangkan tulisan akademis secara iteratif.', tags:['Multi-turn','Iteratif'] },
            { icon:'🔍', title:'Hexa-Source Reference Finder', desc:'Referensi dari 6 sumber termasuk filter eksklusif jurnal terindeks Scopus via OpenAlex dan Semantic Scholar (200 juta paper).', tags:['CrossRef','DOAJ','OpenAlex','🟠 Scopus','Semantic Scholar'] },
            { icon:'✍️', title:'Paraphraser & Humanizer', desc:'Parafrase, humanisasi, formalkan, atau elaborasi teks akademis. Bebas dari AI detector dengan suara penulis yang otentik.', tags:['Humanize','Anti AI-Detect'] },
            { icon:'🎓', title:'Academic Reviewer', desc:'Evaluasi naskah secara mendalam: struktur, argumentasi, metodologi, sitasi, dan rekomendasi perbaikan level Scopus Q1/Q2.', tags:['Q1/Q2','Metodologi'] },
            { icon:'📄', title:'Journal Converter', desc:'Konversi draft menjadi artikel siap submit ke jurnal Q1/Q2 dengan analisis novelty, struktur IMRaD, dan referensi terintegrasi.', tags:['Q1/Q2','Konversi','DOCX/PDF'] },
          ].map((f, i) => (
            <div key={i} className="feature-card">
              <div className="feature-lock">🔒 Premium</div>
              <div className="feature-icon">{f.icon}</div>
              <h3 className="feature-title">{f.title}</h3>
              <p className="feature-desc">{f.desc}</p>
              <div className="feature-tags">
                {f.tags.map(t => <span key={t} className="tag">{t}</span>)}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="section section-dark">
        <div className="section-header">
          <h2>💎 Keanggotaan Premium</h2>
        </div>
        <div className="pricing-card">
          <div className="pricing-price">
            <span className="price-amount">Rp 100.000</span>
            <span className="price-period">per bulan · aktif 30 hari sejak aktivasi</span>
          </div>
          <ul className="pricing-features">
            {['Akses penuh semua fitur AI Writer','Dual-AI Pipeline (Gemini Pro + Claude)','Generate dokumen tanpa batas sesi','Referensi CrossRef terverifikasi','Export DOCX & PDF','Paraphraser & Humanizer premium','Academic Reviewer & Journal Converter','Dukungan teknis via WhatsApp'].map(f => (
              <li key={f}><span className="check">✓</span> {f}</li>
            ))}
          </ul>
          <button className="btn-primary btn-full" onClick={() => onAuth('register')}>Bergabung Sekarang</button>
        </div>
      </section>

      {/* How to Join */}
      <section className="section">
        <div className="section-header">
          <h2>📋 Cara Bergabung</h2>
        </div>
        <div className="steps-grid">
          {[
            { n:'1', t:'Daftar Akun', d:'Isi formulir registrasi dengan data diri lengkap dan buat password akun Anda.' },
            { n:'2', t:'Bayar via BSI', d:'Transfer Rp 100.000 ke rekening BSI 7108946096 a.n. Iskandar dan simpan bukti transfer.' },
            { n:'3', t:'Konfirmasi WA', d:'Kirim bukti pembayaran ke WhatsApp admin 081250955443 beserta email registrasi.' },
            { n:'4', t:'Akun Aktif', d:'Admin mengaktifkan akun Anda. Login dan nikmati semua fitur premium selama 30 hari.' },
          ].map(s => (
            <div key={s.n} className="step-card">
              <div className="step-num">{s.n}</div>
              <h4 className="step-title">{s.t}</h4>
              <p className="step-desc">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="section section-dark">
        <div className="section-header"><h2>📞 Kontak & Dukungan</h2></div>
        <div className="contact-grid">
          <div className="contact-card">
            <div className="contact-icon">💬</div>
            <h5>WhatsApp Admin</h5>
            <p>Konfirmasi pembayaran, aktivasi akun, dan dukungan teknis</p>
            <p className="contact-phone">081250955443</p>
            <a href="https://wa.me/6281250955443?text=Halo%20Admin%20Scholaris%2C%20saya%20ingin%20mendaftar%20keanggotaan." target="_blank" rel="noreferrer" className="btn-wa">💬 Hubungi Admin</a>
          </div>
          <div className="contact-card">
            <div className="contact-icon">👨‍🏫</div>
            <h5>SCHOLARIS' DIGITAL LAB</h5>
            <p><strong>Dr. Iskandar Zainuddin, M.Ag.</strong></p>
            <p>Dosen & Pengembang Platform</p>
            <p>UIN Sultan Aji Muhammad Idris Samarinda</p>
            <p>Kalimantan Timur, Indonesia</p>
          </div>
        </div>
      </section>

      <footer className="landing-footer">
        <p>© 2025 SCHOLARIS Digital Lab · Dr. Iskandar Zainuddin, M.Ag. · UINSI Samarinda</p>
      </footer>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── WRITER PAGE ──────────────────────────────────────────
// ════════════════════════════════════════════════════════
function WriterPage({ user, stats, saveStats, biblio, addToBiblio, saveHistory, notify }: {
  user: User; stats: any; saveStats: any;
  biblio: RefItem[]; addToBiblio: (r: RefItem) => void;
  saveHistory: (d: HistoryDoc) => void; notify: (m: string, t: any) => void;
}) {
  const [mode, setMode] = useState('segmented-article');
  const [model, setModel] = useState('gemini-2.5-pro-preview-06-05');
  const [lang, setLang] = useState('id');
  const [citation, setCitation] = useState('apa7');
  const [temp, setTemp] = useState('0.4');
  const [title, setTitle] = useState('');
  const [instructions, setInstructions] = useState('');
  const [keywords, setKeywords] = useState('');
  const [refCount, setRefCount] = useState('15');
  const [yearFrom, setYearFrom] = useState('2019');
  const [yearTo, setYearTo] = useState(new Date().getFullYear().toString());
  const [grokGround, setGrokGround] = useState(true);
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState('');
  const [refs, setRefs] = useState<RefItem[]>([]);
  const [progress, setProgress] = useState<{ title: string; steps: string[]; current: number } | null>(null);
  const [dualProgress, setDualProgress] = useState<{ gemini: string; claude: string } | null>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  const isSegmented = mode.startsWith('segmented-');
  const isDual = model === 'dual-ai';

  function getSegments() {
    if (mode === 'segmented-article') return ['Abstrak','Pendahuluan','Tinjauan Pustaka','Metodologi','Hasil & Pembahasan','Kesimpulan','Daftar Pustaka'];
    if (mode === 'segmented-proposal') return ['Latar Belakang','Rumusan & Tujuan','Tinjauan Pustaka','Metodologi','Rencana Kerja','Daftar Pustaka'];
    if (mode === 'segmented-thesis') return ['BAB I Pendahuluan','BAB II Kajian Pustaka','BAB III Metodologi','BAB IV Hasil & Pembahasan','BAB V Penutup','Daftar Pustaka'];
    if (mode === 'segmented-slr') return ['Protocol & Search Strategy','Identification & Screening','Quality Assessment','Data Extraction','Synthesis','Conclusion & References'];
    return [];
  }

  async function generate() {
    if (!title.trim()) { notify('Isi judul/topik terlebih dahulu.', 'error'); return; }
    if (user.role !== 'premium') { notify('Fitur ini khusus member Premium. Hubungi admin untuk upgrade.', 'info'); return; }
    setLoading(true); setOutput(''); setRefs([]); setProgress(null); setDualProgress(null);

    try {
      const biblioContext = biblio.length > 0 ? biblio.map(r =>
        `- ${r.authors} (${r.year}). ${r.title}. ${r.journal}. DOI: ${r.doi}`
      ).join('\n') : '';

      if (isSegmented) {
        const segs = getSegments();
        setProgress({ title: 'Segmented Generation Engine', steps: segs, current: 0 });
        let fullDoc = '';

        for (let i = 0; i < segs.length; i++) {
          setProgress({ title: `Generating: ${segs[i]}`, steps: segs, current: i });
          const segPayload = {
            action: 'generate',
            model, mode, lang, citation, temperature: parseFloat(temp),
            title, instructions, keywords, refCount: parseInt(refCount),
            yearFrom: parseInt(yearFrom), yearTo: parseInt(yearTo),
            grokGrounding: grokGround,
            segment: segs[i], segmentIndex: i, totalSegments: segs.length,
            previousContent: fullDoc.slice(-2000),
            biblioContext,
          };
          const res = await callGAS(segPayload);
          if (res.content) {
            fullDoc += (fullDoc ? '\n\n---\n\n' : '') + res.content;
            setOutput(fullDoc);
            if (res.references) setRefs(prev => [...prev, ...res.references]);
            outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
          }
        }

        setProgress(null);
        const wc = wordCount(fullDoc);
        const ns = { ...stats, words: stats.words + wc, sessions: stats.sessions + 1 };
        saveStats(ns);
        saveHistory({ id: Date.now().toString(), title, mode, model, date: formatDate(), words: wc, content: fullDoc });
        notify(`✅ Dokumen selesai! ${wc.toLocaleString()} kata.`, 'success');

      } else if (isDual) {
        setDualProgress({ gemini: 'Memproses...', claude: 'Menunggu...' });
        const payload = {
          action: 'generate', model: 'dual-ai', mode, lang, citation,
          temperature: parseFloat(temp), title, instructions, keywords,
          refCount: parseInt(refCount), yearFrom: parseInt(yearFrom), yearTo: parseInt(yearTo),
          grokGrounding: grokGround, biblioContext,
        };
        setDualProgress({ gemini: 'Memproses...', claude: 'Menunggu...' });
        const res = await callGAS(payload);
        setDualProgress({ gemini: '✅ Selesai', claude: '✅ Selesai' });
        if (res.content) {
          setOutput(res.content);
          if (res.references) setRefs(res.references);
          const wc = wordCount(res.content);
          const ns = { ...stats, words: stats.words + wc, sessions: stats.sessions + 1 };
          saveStats(ns);
          saveHistory({ id: Date.now().toString(), title, mode, model, date: formatDate(), words: wc, content: res.content });
          notify(`✅ Dual-AI selesai! ${wc.toLocaleString()} kata.`, 'success');
        }
        setTimeout(() => setDualProgress(null), 3000);

      } else {
        const payload = {
          action: 'generate', model, mode, lang, citation,
          temperature: parseFloat(temp), title, instructions, keywords,
          refCount: parseInt(refCount), yearFrom: parseInt(yearFrom), yearTo: parseInt(yearTo),
          grokGrounding: grokGround, biblioContext,
        };
        const res = await callGAS(payload);
        if (res.content) {
          setOutput(res.content);
          if (res.references) setRefs(res.references);
          const wc = wordCount(res.content);
          const ns = { ...stats, words: stats.words + wc, sessions: stats.sessions + 1 };
          saveStats(ns);
          saveHistory({ id: Date.now().toString(), title, mode, model, date: formatDate(), words: wc, content: res.content });
          notify(`✅ Berhasil! ${wc.toLocaleString()} kata.`, 'success');
        } else {
          notify(res.message || 'Generate gagal.', 'error');
        }
      }
    } catch (err: any) {
      notify('Error: ' + (err.message || 'Koneksi gagal.'), 'error');
    }
    setLoading(false);
  }

  function copyOutput() {
    navigator.clipboard.writeText(output);
    notify('✅ Teks disalin!', 'success');
  }

  function downloadTxt() {
    const blob = new Blob([output], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = `SCHOLARIS_${title.slice(0, 30).replace(/\s+/g,'_')}.txt`;
    a.click();
  }

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>⚡ AI Academic Writer</h1>
        <p>Dual-AI Pipeline — Gemini 3.1 Pro + Claude Sonnet 4.6 Extended</p>
      </div>

      {/* Stats Bar */}
      <div className="stats-bar">
        {[
          { n: stats.words.toLocaleString(), l: 'Kata Dihasilkan' },
          { n: stats.refs.toString(), l: 'Referensi CrossRef' },
          { n: stats.sessions.toString(), l: 'Sesi Hari Ini' },
          { n: AI_MODELS.find(m2=>m2.value===model)?.label.replace(/[🧠🎭🤖🔬🦙⚡🚀]/g,'').trim().split(' ')[0] || '—', l: 'Model Aktif' },
        ].map(s => (
          <div key={s.l} className="stat-bar-item">
            <span className="stat-bar-num">{s.n}</span>
            <span className="stat-bar-label">{s.l}</span>
          </div>
        ))}
      </div>

      {/* Config Card */}
      <div className="card">
        <div className="card-header">⚙️ Konfigurasi Penulisan Akademis</div>
        <div className="form-grid-2">
          <div className="form-group">
            <label>Mode Penulisan</label>
            <select value={mode} onChange={e => setMode(e.target.value)}>
              {WRITE_MODES.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Model AI</label>
            <select value={model} onChange={e => setModel(e.target.value)}>
              {AI_MODELS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Bahasa Output</label>
            <select value={lang} onChange={e => setLang(e.target.value)}>
              {LANGUAGES.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Gaya Sitasi</label>
            <select value={citation} onChange={e => setCitation(e.target.value)}>
              {CITATION_STYLES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Temperatur (0–1)</label>
            <input type="number" min="0" max="1" step="0.1" value={temp} onChange={e => setTemp(e.target.value)} />
          </div>
        </div>

        <div className="form-group">
          <label>Judul / Topik Penelitian</label>
          <input placeholder="Masukkan judul atau topik penelitian..." value={title} onChange={e => setTitle(e.target.value)} />
        </div>
        <div className="form-group">
          <label>Instruksi Tambahan <span className="label-note">(konteks, cakupan, variabel, dll.)</span></label>
          <textarea rows={3} placeholder="Contoh: Gunakan kerangka maqāṣid al-sharīʿah. Fokus konteks UMKM digital. Target Scopus Q2. Minimal 7.000 kata." value={instructions} onChange={e => setInstructions(e.target.value)} />
        </div>
        <div className="form-group">
          <label>Kata Kunci Referensi Hexa-Source</label>
          <input placeholder="islamic economics, zakat, fintech, Indonesia" value={keywords} onChange={e => setKeywords(e.target.value)} />
        </div>

        <div className="form-grid-3">
          <div className="form-group">
            <label>Jumlah Referensi</label>
            <input type="number" min="5" max="50" value={refCount} onChange={e => setRefCount(e.target.value)} />
          </div>
          <div className="form-group">
            <label>Filter Tahun (dari)</label>
            <input type="number" min="2000" value={yearFrom} onChange={e => setYearFrom(e.target.value)} />
          </div>
          <div className="form-group">
            <label>Filter Tahun (sampai)</label>
            <input type="number" max="2026" value={yearTo} onChange={e => setYearTo(e.target.value)} />
          </div>
        </div>

        {/* Grok Grounding Toggle */}
        <div className="grok-panel">
          <div className="grok-info">
            <span className="grok-title">⚡ Grok 4.20 Empirical Grounding</span>
            <span className="grok-desc">Pengayaan data empiris, statistik, & fakta terkini oleh Grok 4.20 (xAI)</span>
          </div>
          <button className={`toggle-btn ${grokGround ? 'toggle-on' : 'toggle-off'}`} onClick={() => setGrokGround(!grokGround)}>
            <span className="toggle-knob" />
            <span className="toggle-label">{grokGround ? 'Aktif' : 'Nonaktif'}</span>
          </button>
        </div>

        <button className="btn-generate" onClick={generate} disabled={loading}>
          {loading ? <><span className="spinner" /> Generating...</> : '🚀 Generate Tulisan Akademis'}
        </button>
      </div>

      {/* Progress */}
      {progress && (
        <div className="progress-card">
          <div className="progress-header">
            <span className="progress-spinner" />
            <span>{progress.title}</span>
          </div>
          <div className="progress-steps">
            {progress.steps.map((s, i) => (
              <div key={i} className={`progress-step ${i < progress.current ? 'step-done' : i === progress.current ? 'step-active' : 'step-pending'}`}>
                <span className="step-icon">{i < progress.current ? '✅' : i === progress.current ? '⚡' : '○'}</span>
                <span>{s}</span>
              </div>
            ))}
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${(progress.current / progress.steps.length) * 100}%` }} />
          </div>
        </div>
      )}

      {/* Dual AI Progress */}
      {dualProgress && (
        <div className="dual-progress">
          <div className="dual-model">
            <div className="dual-icon">🧠</div>
            <div>
              <p className="dual-name">Gemini 3.1 Pro Preview ✨</p>
              <p className="dual-status">{dualProgress.gemini}</p>
            </div>
          </div>
          <div className="dual-arrow">→</div>
          <div className="dual-model">
            <div className="dual-icon">🎭</div>
            <div>
              <p className="dual-name">Claude Sonnet 4.6 Extended ✨</p>
              <p className="dual-status">{dualProgress.claude}</p>
            </div>
          </div>
        </div>
      )}

      {/* Output */}
      {output && (
        <div className="output-card" ref={outputRef}>
          <div className="output-header">
            <span>📄 Hasil Generasi — {wordCount(output).toLocaleString()} kata</span>
            <div className="output-actions">
              <button className="btn-sm" onClick={copyOutput}>📋 Salin</button>
              <button className="btn-sm" onClick={downloadTxt}>⬇️ Download</button>
            </div>
          </div>
          <div className="output-body" dangerouslySetInnerHTML={{ __html: output.replace(/\n/g, '<br/>') }} />
        </div>
      )}

      {/* References Found */}
      {refs.length > 0 && (
        <div className="refs-found">
          <div className="refs-header">
            <span>📚 Referensi Ditemukan ({refs.length})</span>
          </div>
          <div className="refs-list">
            {refs.map((r, i) => (
              <RefCard key={i} ref_={r} onAdd={addToBiblio} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Ref Card ──
function RefCard({ ref_, onAdd }: { ref_: RefItem; onAdd: (r: RefItem) => void }) {
  return (
    <div className="ref-card">
      <div className="ref-meta">
        {ref_.scopusIndexed && <span className="badge-scopus">🟠 Scopus</span>}
        {ref_.openAccess && <span className="badge-oa">🔓 OA</span>}
        {ref_.source && <span className="badge-source">{ref_.source}</span>}
      </div>
      <p className="ref-title">{ref_.title}</p>
      <p className="ref-authors">{ref_.authors} ({ref_.year})</p>
      <p className="ref-journal">{ref_.journal}</p>
      {ref_.doi && <a className="ref-doi" href={`https://doi.org/${ref_.doi}`} target="_blank" rel="noreferrer">DOI: {ref_.doi}</a>}
      {ref_.citations !== undefined && <span className="ref-cites">📊 {ref_.citations} sitasi</span>}
      {ref_.abstract && <p className="ref-abstract">{ref_.abstract.slice(0, 200)}...</p>}
      <button className="btn-add-ref" onClick={() => onAdd(ref_)}>+ Tambah ke Bibliografi</button>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── MULTI-TURN WRITER ────────────────────────────────────
// ════════════════════════════════════════════════════════
function MultiWriterPage({ user, saveHistory, notify }: {
  user: User; stats?: any; saveStats?: any;
  saveHistory: (d: HistoryDoc) => void; notify: (m: string, t: any) => void;
}) {
  const [model, setModel] = useState('gemini-2.5-pro-preview-06-05');
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; content: string }[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState('chat');
  const chatRef = useRef<HTMLDivElement>(null);

  async function sendMessage() {
    if (!input.trim()) return;
    if (user.role !== 'premium') { notify('Fitur ini khusus member Premium.', 'info'); return; }
    const userMsg = { role: 'user' as const, content: input };
    const newMsgs = [...messages, userMsg];
    setMessages(newMsgs); setInput(''); setLoading(true);
    try {
      const res = await callGAS({
        action: 'multiTurn', model, mode,
        messages: newMsgs.map(m => ({ role: m.role, content: m.content })),
        currentMessage: input,
      });
      if (res.content) {
        setMessages([...newMsgs, { role: 'ai', content: res.content }]);
        chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: 'smooth' });
      } else notify(res.message || 'Gagal mendapat respons.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false);
  }

  function exportAll() {
    const text = messages.map(m => `[${m.role.toUpperCase()}]\n${m.content}`).join('\n\n---\n\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'SCHOLARIS_MultiTurn.txt'; a.click();
    const wc = wordCount(text);
    saveHistory({ id: Date.now().toString(), title: 'Multi-Turn Session', mode: 'multi-turn', model, date: formatDate(), words: wc, content: text });
    notify('✅ Export berhasil!', 'success');
  }

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>💬 Multi-Turn Writer</h1>
        <p>Dialog interaktif multi-giliran untuk membangun tulisan akademis secara iteratif</p>
      </div>

      <div className="card">
        <div className="form-grid-2">
          <div className="form-group">
            <label>Model AI</label>
            <select value={model} onChange={e => setModel(e.target.value)}>
              {AI_MODELS.filter(m => m.value !== 'dual-ai').map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Mode</label>
            <select value={mode} onChange={e => setMode(e.target.value)}>
              <option value="chat">💬 Chat Akademis</option>
              <option value="book">📚 Book Mode (Bab per Bab)</option>
              <option value="thesis">🎓 Thesis Builder</option>
            </select>
          </div>
        </div>

        {/* Chat Area */}
        <div className="chat-area" ref={chatRef}>
          {messages.length === 0 && (
            <div className="chat-empty">
              <div className="chat-empty-icon">💬</div>
              <p>Mulai percakapan akademis Anda</p>
              <p className="chat-empty-hint">Contoh: "Buat kerangka bab I tesis saya tentang ekonomi Islam digital"</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`chat-msg chat-msg-${m.role}`}>
              <div className="chat-avatar">{m.role === 'user' ? '👤' : '🤖'}</div>
              <div className="chat-bubble">
                <div dangerouslySetInnerHTML={{ __html: m.content.replace(/\n/g, '<br/>') }} />
              </div>
            </div>
          ))}
          {loading && (
            <div className="chat-msg chat-msg-ai">
              <div className="chat-avatar">🤖</div>
              <div className="chat-bubble chat-loading"><span /><span /><span /></div>
            </div>
          )}
        </div>

        <div className="chat-input-area">
          <textarea
            className="chat-input"
            rows={3}
            placeholder="Ketik pesan akademis Anda..."
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) sendMessage(); }}
          />
          <div className="chat-input-actions">
            <span className="chat-hint">Ctrl+Enter untuk kirim</span>
            <div>
              {messages.length > 0 && (
                <button className="btn-sm" onClick={exportAll}>⬇️ Export</button>
              )}
              <button className="btn-primary" onClick={sendMessage} disabled={loading}>
                {loading ? <span className="spinner" /> : '📨 Kirim'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── REFERENCES PAGE ──────────────────────────────────────
// ════════════════════════════════════════════════════════
function ReferencesPage({ addToBiblio, notify }: {
  biblio?: RefItem[]; addToBiblio: (r: RefItem) => void; notify: (m: string, t: any) => void;
}) {
  const [query, setQuery] = useState('');
  const [count, setCount] = useState('15');
  const [docType, setDocType] = useState('all');
  const [yearFrom, setYearFrom] = useState('2019');
  const [yearTo, setYearTo] = useState(new Date().getFullYear().toString());
  const [sort, setSort] = useState('relevance');
  const [minCites] = useState('0');
  const [openAccess, setOpenAccess] = useState('all');
  const [sources, setSources] = useState(DB_SOURCES.map(s => ({ ...s })));
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<RefItem[]>([]);
  const [searched, setSearched] = useState(false);

  function toggleSource(id: string) {
    setSources(prev => prev.map(s => s.id === id ? { ...s, active: !s.active } : s));
  }

  async function search() {
    if (!query.trim()) { notify('Masukkan kata kunci pencarian.', 'error'); return; }
    setLoading(true); setResults([]); setSearched(false);
    try {
      const activeSrcs = sources.filter(s => s.active).map(s => s.id);
      const res = await callGAS({
        action: 'findReferences', query, count: parseInt(count),
        docType, yearFrom: parseInt(yearFrom), yearTo: parseInt(yearTo),
        sort, minCites: parseInt(minCites), openAccess, sources: activeSrcs,
      });
      if (res.references) {
        setResults(res.references);
        notify(`✅ ${res.references.length} referensi ditemukan dari ${activeSrcs.length} sumber.`, 'success');
      } else notify(res.message || 'Pencarian gagal.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false); setSearched(true);
  }

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>🔍 Hexa-Source Reference Finder</h1>
        <p>Temukan referensi dari <strong>6 sumber</strong> termasuk Scopus & Semantic Scholar (200 juta paper)</p>
        <div className="ref-badges">
          {['● CrossRef','● DOAJ','● Europe PMC','● OpenAlex','🟠 Scopus','● Semantic Scholar','✓ DOI Verified','✓ Scopus Filter','✓ Open Access'].map(b => (
            <span key={b} className="ref-badge">{b}</span>
          ))}
        </div>
      </div>

      <div className="card">
        <div className="form-group">
          <label>Kata Kunci Pencarian</label>
          <input
            placeholder="islamic economics zakat fintech Indonesia"
            value={query} onChange={e => setQuery(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') search(); }}
          />
        </div>

        <div className="form-grid-3">
          <div className="form-group">
            <label>Jumlah</label>
            <select value={count} onChange={e => setCount(e.target.value)}>
              {['5','10','15','20','30','50'].map(n => <option key={n} value={n}>{n} referensi</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Tipe Dokumen</label>
            <select value={docType} onChange={e => setDocType(e.target.value)}>
              <option value="all">Semua Tipe</option>
              <option value="journal-article">Journal Article</option>
              <option value="book-chapter">Book Chapter</option>
              <option value="proceedings">Proceedings</option>
            </select>
          </div>
          <div className="form-group">
            <label>Tahun Dari</label>
            <input type="number" value={yearFrom} onChange={e => setYearFrom(e.target.value)} />
          </div>
          <div className="form-group">
            <label>Tahun Sampai</label>
            <input type="number" value={yearTo} onChange={e => setYearTo(e.target.value)} />
          </div>
          <div className="form-group">
            <label>Urutkan</label>
            <select value={sort} onChange={e => setSort(e.target.value)}>
              <option value="relevance">Relevansi</option>
              <option value="citations">Paling Disitasi</option>
              <option value="newest">Terbaru</option>
            </select>
          </div>
          <div className="form-group">
            <label>Open Access</label>
            <select value={openAccess} onChange={e => setOpenAccess(e.target.value)}>
              <option value="all">Semua</option>
              <option value="true">Open Access Only</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Sumber Database <span className="label-note">— klik untuk aktif/nonaktif</span></label>
          <div className="source-chips">
            {sources.map(s => (
              <button
                key={s.id}
                className={`source-chip ${s.active ? 'chip-active' : 'chip-inactive'}`}
                style={s.active ? { borderColor: s.color, backgroundColor: s.color + '22' } : {}}
                onClick={() => toggleSource(s.id)}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <button className="btn-generate" onClick={search} disabled={loading}>
          {loading ? <><span className="spinner" /> Mencari dari {sources.filter(s=>s.active).length} sumber...</> : '🔍 Cari Referensi'}
        </button>
      </div>

      {loading && (
        <div className="search-progress">
          {sources.filter(s => s.active).map(s => (
            <div key={s.id} className="search-source-item">
              <span className="search-source-dot" style={{ background: s.color }} />
              <span>{s.label}</span>
              <span className="search-source-loading">...</span>
            </div>
          ))}
        </div>
      )}

      {searched && results.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">🔍</div>
          <p>Tidak ada hasil ditemukan. Coba kata kunci berbeda.</p>
        </div>
      )}

      {results.length > 0 && (
        <div className="refs-found">
          <div className="refs-header">
            <span>📚 {results.length} Referensi Ditemukan</span>
            <button className="btn-sm" onClick={() => results.forEach(addToBiblio)}>+ Tambah Semua ke Bibliografi</button>
          </div>
          <div className="refs-list">
            {results.map((r, i) => <RefCard key={i} ref_={r} onAdd={addToBiblio} />)}
          </div>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── PARAPHRASE PAGE ──────────────────────────────────────
// ════════════════════════════════════════════════════════
function ParaphrasePage({ notify, stats, saveStats }: {
  notify: (m: string, t: any) => void; stats: any; saveStats: any;
}) {
  const [paraMode, setParaMode] = useState('paraphrase');
  const [lang, setLang] = useState('id');
  const [model, setModel] = useState('claude-sonnet-4-6');
  const [intensity, setIntensity] = useState(3);
  const [inputText, setInputText] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  async function transform() {
    if (!inputText.trim()) { notify('Masukkan teks untuk ditransformasi.', 'error'); return; }
    setLoading(true); setResult('');
    try {
      const res = await callGAS({
        action: 'paraphrase', mode: paraMode, lang, model, intensity,
        text: inputText,
      });
      if (res.content) {
        setResult(res.content);
        const ns = { ...stats, words: stats.words + wordCount(res.content) };
        saveStats(ns);
        notify('✅ Transformasi selesai!', 'success');
      } else notify(res.message || 'Gagal.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false);
  }

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>✍️ Academic Paraphraser & Rewriter</h1>
        <p>Transformasi teks akademis dengan strategi linguistik profesional — otentik, bervariasi, dan berkarakter ilmiah tinggi</p>
      </div>

      <div className="card">
        <div className="para-mode-grid">
          {PARA_MODES.map(m => (
            <button key={m.value} className={`para-mode-btn ${paraMode === m.value ? 'para-mode-active' : ''}`} onClick={() => setParaMode(m.value)}>
              <span className="para-mode-icon">{m.icon}</span>
              <span>{m.label.replace(/[🔄🧑📐📈🗜️🌐]/g,'').trim()}</span>
            </button>
          ))}
        </div>

        <div className="form-grid-3">
          <div className="form-group">
            <label>Bahasa Output</label>
            <select value={lang} onChange={e => setLang(e.target.value)}>
              {LANGUAGES.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Intensitas Transformasi</label>
            <div className="intensity-bar">
              {[1,2,3,4,5].map(n => (
                <button key={n} className={`intensity-dot ${intensity >= n ? 'intensity-active' : ''}`} onClick={() => setIntensity(n)}>{n}</button>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label>Model AI</label>
            <select value={model} onChange={e => setModel(e.target.value)}>
              {AI_MODELS.filter(m => m.value !== 'dual-ai').map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Teks Asli <span className="label-note">{wordCount(inputText)} kata</span></label>
          <textarea rows={8} placeholder="Tempel teks akademis di sini..." value={inputText} onChange={e => setInputText(e.target.value)} />
        </div>

        <button className="btn-generate" onClick={transform} disabled={loading}>
          {loading ? <><span className="spinner" /> Mentransformasi...</> : `${PARA_MODES.find(m=>m.value===paraMode)?.icon || '✍️'} Transformasi Teks`}
        </button>
      </div>

      {result ? (
        <div className="output-card">
          <div className="output-header">
            <span>✅ Hasil Transformasi — {wordCount(result).toLocaleString()} kata</span>
            <div className="output-actions">
              <button className="btn-sm" onClick={() => { navigator.clipboard.writeText(result); notify('Disalin!', 'success'); }}>📋 Salin</button>
            </div>
          </div>
          <div className="output-body" dangerouslySetInnerHTML={{ __html: result.replace(/\n/g, '<br/>') }} />
        </div>
      ) : (
        <div className="empty-state">
          <div className="empty-icon">✍️</div>
          <p>Belum ada hasil</p>
          <p className="empty-hint">Tempel teks di atas, pilih mode, lalu klik Transformasi Teks</p>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── REVIEWER PAGE ────────────────────────────────────────
// ════════════════════════════════════════════════════════
function ReviewerPage({ notify }: { notify: (m: string, t: any) => void }) {
  const [aspect, setAspect] = useState('comprehensive');
  const [strictness, setStrictness] = useState('standard');
  const [model, setModel] = useState('gemini-2.5-pro-preview-06-05');
  const [text, setText] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  async function review() {
    if (!text.trim()) { notify('Masukkan teks naskah untuk direview.', 'error'); return; }
    setLoading(true); setResult('');
    try {
      const res = await callGAS({ action: 'review', aspect, strictness, model, text });
      if (res.content) { setResult(res.content); notify('✅ Review selesai!', 'success'); }
      else notify(res.message || 'Review gagal.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false);
  }

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>🎓 Academic Reviewer & Critique Engine</h1>
        <p>Evaluasi naskah akademis secara mendalam: struktur, argumentasi, metodologi, sitasi, dan rekomendasi perbaikan</p>
      </div>

      <div className="card">
        <div className="form-grid-3">
          <div className="form-group">
            <label>Aspek Review</label>
            <select value={aspect} onChange={e => setAspect(e.target.value)}>
              {REVIEW_ASPECTS.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Tingkat Keketatan</label>
            <select value={strictness} onChange={e => setStrictness(e.target.value)}>
              <option value="light">Ringan (Feedback Konstruktif)</option>
              <option value="standard">Standar (Scopus Level)</option>
              <option value="strict">Ketat (Q1/Q2 Level)</option>
            </select>
          </div>
          <div className="form-group">
            <label>Model AI</label>
            <select value={model} onChange={e => setModel(e.target.value)}>
              {AI_MODELS.filter(m => m.value !== 'dual-ai').map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Teks Naskah untuk Direview <span className="label-note">{wordCount(text)} kata</span></label>
          <textarea rows={10} placeholder="Tempel teks naskah akademis di sini..." value={text} onChange={e => setText(e.target.value)} />
        </div>

        <button className="btn-generate" onClick={review} disabled={loading}>
          {loading ? <><span className="spinner" /> Mereview...</> : '🎓 Mulai Review Akademis'}
        </button>
      </div>

      {result && (
        <div className="output-card">
          <div className="output-header">
            <span>📝 Hasil Review Akademis</span>
            <button className="btn-sm" onClick={() => { navigator.clipboard.writeText(result); notify('Disalin!', 'success'); }}>📋 Salin</button>
          </div>
          <div className="output-body" dangerouslySetInnerHTML={{ __html: result.replace(/\n/g, '<br/>') }} />
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── CONVERTER PAGE ───────────────────────────────────────
// ════════════════════════════════════════════════════════
function ConverterPage({ saveHistory, notify, stats, saveStats }: {
  biblio?: RefItem[]; addToBiblio?: (r: RefItem) => void;
  saveHistory: (d: HistoryDoc) => void; notify: (m: string, t: any) => void;
  stats: any; saveStats: any;
}) {
  const [stage, setStage] = useState(0);
  const [srcType, setSrcType] = useState('');
  const [srcText, setSrcText] = useState('');
  const [srcLang, setSrcLang] = useState('id');
  const [outLang, setOutLang] = useState('id');
  const [model, setModel] = useState('gemini-2.5-pro-preview-06-05');
  const [analysis, setAnalysis] = useState<Record<string, string>>({});
  const [targetLevel, setTargetLevel] = useState('scopus-q2');
  const [citation, setCitation] = useState('apa7');
  const [tempVal, setTempVal] = useState('0.4');
  const [scopes, setScopes] = useState<string[]>(['Islamic Studies']);
  const [targetJournal, setTargetJournal] = useState('');
  const [extraInstructions, setExtraInstructions] = useState('');
  const [convRefs, setConvRefs] = useState<RefItem[]>([]);
  const [selectedRefs, setSelectedRefs] = useState<string[]>([]);
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [progressTitle, setProgressTitle] = useState('');

  const SCOPE_OPTIONS = ['Islamic Studies','Islamic Economics & Finance','Quranic Studies','Social Sciences','Education','Economics','Law','Management','Digital Humanities','Environmental Studies','Public Policy','Psychology','Communication','Computer Science'];

  function toggleScope(s: string) {
    setScopes(prev => prev.includes(s) ? prev.filter(x=>x!==s) : [...prev,s]);
  }

  async function doAnalyze() {
    if (!srcType) { notify('Pilih tipe dokumen sumber.', 'error'); return; }
    if (!srcText.trim()) { notify('Tempel teks dokumen sumber.', 'error'); return; }
    setLoading(true); setProgressTitle('Menganalisis dokumen sumber...');
    try {
      const res = await callGAS({ action: 'analyzeDocument', srcType, text: srcText, srcLang, model });
      if (res.analysis) { setAnalysis(res.analysis); setStage(1); notify('✅ Analisis selesai!', 'success'); }
      else notify(res.message || 'Analisis gagal.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false); setProgressTitle('');
  }

  async function fetchConvRefs() {
    setLoading(true); setProgressTitle('Mencari referensi CrossRef...');
    try {
      const keywords = [analysis.title, analysis.keywords].filter(Boolean).join(', ');
      const res = await callGAS({ action: 'findReferences', query: keywords, count: 20, sources: ['crossref','scopus','semantic'] });
      if (res.references) { setConvRefs(res.references); setStage(3); notify(`✅ ${res.references.length} referensi ditemukan.`, 'success'); }
      else notify(res.message || 'Pencarian referensi gagal.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false); setProgressTitle('');
  }

  async function doConvert() {
    setLoading(true);
    const steps = ['Ekstraksi kontribusi utama','Perkuat novelty & research gap','Strukturisasi IMRaD','Integrasi referensi','Finalisasi artikel'];
    for (let i = 0; i < steps.length; i++) {
      setProgressTitle(steps[i]);
      await new Promise(r => setTimeout(r, 500));
    }
    try {
      const selRefs = convRefs.filter(r => selectedRefs.includes(r.doi));
      const res = await callGAS({
        action: 'convertToJournal', srcType, srcText, analysis,
        targetLevel, citation, temperature: parseFloat(tempVal),
        scopes, targetJournal, extraInstructions, outLang, model,
        selectedRefs: selRefs,
        biblioContext: selRefs.map(r => `- ${r.authors} (${r.year}). ${r.title}. DOI: ${r.doi}`).join('\n'),
      });
      if (res.content) {
        setOutput(res.content);
        setStage(5);
        const wc = wordCount(res.content);
        saveHistory({ id: Date.now().toString(), title: analysis.title || 'Journal Article', mode: 'journal-converter', model, date: formatDate(), words: wc, content: res.content });
        const ns = { ...stats, words: stats.words + wc };
        saveStats(ns);
        notify(`✅ Konversi selesai! ${wc.toLocaleString()} kata.`, 'success');
      } else notify(res.message || 'Konversi gagal.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false); setProgressTitle('');
  }

  const STAGES = ['Input & Sumber','Analisis AI','Target Jurnal','Referensi CrossRef','Konversi & Generate','Hasil & Export'];

  return (
    <div className="page-content">
      <div className="page-hero converter-hero">
        <div className="converter-badge">⭐ Scopus Q1 / Q2 Journal Converter</div>
        <h1>From Research to Journal Article</h1>
        <p>Konversi laporan penelitian, skripsi, tesis, disertasi, atau buku menjadi artikel jurnal ilmiah bereputasi Scopus Q1/Q2 secara profesional.</p>
      </div>

      {/* Stepper */}
      <div className="stepper">
        {STAGES.map((s, i) => (
          <button key={i} className={`step ${i === stage ? 'step-current' : i < stage ? 'step-done' : 'step-future'}`} onClick={() => i < stage && setStage(i)}>
            <span className="step-circle">{i < stage ? '✓' : i + 1}</span>
            <span className="step-name">{s}</span>
          </button>
        ))}
      </div>

      {/* Stage 0 */}
      {stage === 0 && (
        <div className="card">
          <div className="card-header">Tahap 1 — Pilih Tipe Dokumen Sumber</div>
          <div className="src-type-grid">
            {[{v:'skripsi',i:'📄',t:'Skripsi',s:'S1 / Sarjana'},{v:'tesis',i:'📘',t:'Tesis',s:'S2 / Magister'},{v:'disertasi',i:'🎓',t:'Disertasi',s:'S3 / Doktor'},{v:'laporan',i:'📊',t:'Laporan Riset',s:'LP2M / Hibah'},{v:'buku',i:'📚',t:'Buku / Bab Buku',s:'Monograf / Chapter'}].map(s => (
              <button key={s.v} className={`src-type-btn ${srcType === s.v ? 'src-type-active' : ''}`} onClick={() => setSrcType(s.v)}>
                <span className="src-type-icon">{s.i}</span>
                <span className="src-type-title">{s.t}</span>
                <span className="src-type-sub">{s.s}</span>
              </button>
            ))}
          </div>
          <div className="form-group">
            <label>Tempel Teks Dokumen Sumber <span className="label-note">{wordCount(srcText)} kata</span></label>
            <textarea rows={10} placeholder="Tempel seluruh dokumen, bab inti, atau gabungan bagian terpenting..." value={srcText} onChange={e => setSrcText(e.target.value)} />
          </div>
          <div className="form-grid-3">
            <div className="form-group">
              <label>Bahasa Dokumen Sumber</label>
              <select value={srcLang} onChange={e => setSrcLang(e.target.value)}>
                {LANGUAGES.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Bahasa Output Jurnal</label>
              <select value={outLang} onChange={e => setOutLang(e.target.value)}>
                {LANGUAGES.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Model AI Konversi</label>
              <select value={model} onChange={e => setModel(e.target.value)}>
                {AI_MODELS.filter(m => m.value !== 'dual-ai').map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
            </div>
          </div>
          <button className="btn-generate" onClick={doAnalyze} disabled={loading}>
            {loading ? <><span className="spinner" /> {progressTitle || 'Menganalisis...'}</> : '🔬 Analisis Dokumen →'}
          </button>
        </div>
      )}

      {/* Stage 1 */}
      {stage === 1 && (
        <div className="card">
          <div className="card-header">Tahap 2 — Hasil Analisis AI</div>
          <p className="card-desc">AI mengekstrak elemen-elemen kunci. Klik field untuk mengedit.</p>
          {Object.entries(analysis).map(([k, v]) => (
            <div key={k} className="form-group">
              <label>{k.charAt(0).toUpperCase() + k.slice(1)}</label>
              <textarea rows={3} value={v} onChange={e => setAnalysis(prev => ({ ...prev, [k]: e.target.value }))} />
            </div>
          ))}
          <button className="btn-generate" onClick={() => setStage(2)}>Lanjut ke Target Jurnal →</button>
        </div>
      )}

      {/* Stage 2 */}
      {stage === 2 && (
        <div className="card">
          <div className="card-header">Tahap 3 — Konfigurasi Target Jurnal</div>
          <div className="form-grid-3">
            <div className="form-group">
              <label>Level Reputasi Target</label>
              <select value={targetLevel} onChange={e => setTargetLevel(e.target.value)}>
                <option value="scopus-q1">Scopus Q1</option>
                <option value="scopus-q2">Scopus Q2</option>
                <option value="sinta-1">SINTA 1</option>
                <option value="sinta-2">SINTA 2</option>
                <option value="international">International (Umum)</option>
              </select>
            </div>
            <div className="form-group">
              <label>Gaya Sitasi</label>
              <select value={citation} onChange={e => setCitation(e.target.value)}>
                {CITATION_STYLES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Temperatur AI</label>
              <input type="number" min="0" max="1" step="0.1" value={tempVal} onChange={e => setTempVal(e.target.value)} />
            </div>
          </div>
          <div className="form-group">
            <label>Bidang Keilmuan / Scope Jurnal</label>
            <div className="scope-chips">
              {SCOPE_OPTIONS.map(s => (
                <button key={s} className={`scope-chip ${scopes.includes(s) ? 'scope-active' : ''}`} onClick={() => toggleScope(s)}>{s}</button>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label>Nama Jurnal Target (opsional)</label>
            <input placeholder="Al-Iqtishad Journal, IJIBEC, dll." value={targetJournal} onChange={e => setTargetJournal(e.target.value)} />
          </div>
          <div className="form-group">
            <label>Instruksi Tambahan (opsional)</label>
            <textarea rows={3} placeholder="Arahan spesifik, variabel, teori, konteks lokal..." value={extraInstructions} onChange={e => setExtraInstructions(e.target.value)} />
          </div>
          <button className="btn-generate" onClick={fetchConvRefs} disabled={loading}>
            {loading ? <><span className="spinner" /> Mencari referensi...</> : 'Cari Referensi CrossRef →'}
          </button>
        </div>
      )}

      {/* Stage 3 */}
      {stage === 3 && (
        <div className="card">
          <div className="card-header">Tahap 4 — Pilih Referensi CrossRef</div>
          <p className="card-desc">Pilih referensi yang relevan untuk diintegrasikan ke dalam artikel.</p>
          <div className="refs-list">
            {convRefs.map((r, i) => (
              <div key={i} className={`ref-card ref-selectable ${selectedRefs.includes(r.doi) ? 'ref-selected' : ''}`}
                onClick={() => setSelectedRefs(prev => prev.includes(r.doi) ? prev.filter(d => d !== r.doi) : [...prev, r.doi])}>
                <div className="ref-select-indicator">{selectedRefs.includes(r.doi) ? '✅' : '○'}</div>
                <div>
                  <p className="ref-title">{r.title}</p>
                  <p className="ref-authors">{r.authors} ({r.year}) — {r.journal}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="selected-count">{selectedRefs.length} referensi dipilih</p>
          <button className="btn-generate" onClick={() => setStage(4)}>Lanjut ke Konversi →</button>
        </div>
      )}

      {/* Stage 4 */}
      {stage === 4 && (
        <div className="card">
          <div className="card-header">Tahap 5 — Konversi & Generate Artikel</div>
          {progressTitle && (
            <div className="progress-card">
              <div className="progress-header"><span className="progress-spinner" /><span>{progressTitle}</span></div>
            </div>
          )}
          <button className="btn-generate" onClick={doConvert} disabled={loading}>
            {loading ? <><span className="spinner" /> {progressTitle || 'Mengkonversi...'}</> : '🚀 Mulai Konversi Journal Converter'}
          </button>
        </div>
      )}

      {/* Stage 5 */}
      {stage === 5 && output && (
        <div className="card">
          <div className="card-header">Tahap 6 — Artikel Jurnal Siap Submit</div>
          <div className="output-actions" style={{ marginBottom: '1rem' }}>
            <button className="btn-sm" onClick={() => { navigator.clipboard.writeText(output); notify('Disalin!', 'success'); }}>📋 Salin</button>
            <button className="btn-sm" onClick={() => {
              const blob = new Blob([output], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a'); a.href = url;
              a.download = 'SCHOLARIS_JournalArticle.txt'; a.click();
            }}>⬇️ Download TXT</button>
          </div>
          <div className="output-body" dangerouslySetInnerHTML={{ __html: output.replace(/\n/g, '<br/>') }} />
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── BIBLIOGRAPHY PAGE ────────────────────────────────────
// ════════════════════════════════════════════════════════
function BibliographyPage({ biblio, setBiblio, notify }: {
  biblio: RefItem[]; setBiblio: (b: RefItem[]) => void; notify: (m: string, t: any) => void;
}) {
  const [format, setFormat] = useState('apa7');
  const [sort, setSort] = useState('alpha');
  const [doiInput, setDoiInput] = useState('');
  const [loading, setLoading] = useState(false);

  function removeRef(doi: string) {
    setBiblio(biblio.filter(r => r.doi !== doi));
    notify('Referensi dihapus.', 'info');
  }

  function formatRef(r: RefItem, fmt: string): string {
    const authors = r.authors || 'Unknown';
    const year = r.year || 'n.d.';
    const title = r.title || 'Untitled';
    const journal = r.journal || '';
    const doi = r.doi ? `https://doi.org/${r.doi}` : '';
    if (fmt === 'apa7') return `${authors} (${year}). ${title}. *${journal}*. ${doi}`;
    if (fmt === 'ieee') return `${authors}, "${title}," *${journal}*, ${year}. ${doi}`;
    if (fmt === 'chicago-footnote') return `${authors}. "${title}." *${journal}* (${year}). ${doi}`;
    if (fmt === 'harvard') return `${authors} ${year}, '${title}', *${journal}*. Available at: ${doi}`;
    return `${authors} (${year}). ${title}. ${journal}. ${doi}`;
  }

  function getSorted() {
    const list = [...biblio];
    if (sort === 'alpha') list.sort((a, b) => a.authors.localeCompare(b.authors));
    if (sort === 'year-desc') list.sort((a, b) => Number(b.year) - Number(a.year));
    if (sort === 'year-asc') list.sort((a, b) => Number(a.year) - Number(b.year));
    return list;
  }

  async function addByDoi() {
    if (!doiInput.trim()) return;
    setLoading(true);
    try {
      const res = await callGAS({ action: 'lookupDOI', doi: doiInput.trim() });
      if (res.reference) {
        const nb = [...biblio, res.reference];
        setBiblio(nb);
        setDoiInput('');
        notify('✅ Referensi ditambahkan!', 'success');
      } else notify(res.message || 'DOI tidak ditemukan.', 'error');
    } catch { notify('Koneksi gagal.', 'error'); }
    setLoading(false);
  }

  function copyAll() {
    const text = getSorted().map((r, i) => `${i + 1}. ${formatRef(r, format)}`).join('\n\n');
    navigator.clipboard.writeText(text);
    notify('✅ Daftar pustaka disalin!', 'success');
  }

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>📚 Bibliography Builder</h1>
        <p>Kumpulkan, kelola, dan format daftar pustaka dari referensi yang ditemukan</p>
      </div>

      <div className="card">
        <div className="form-grid-2">
          <div className="form-group">
            <label>Format Sitasi</label>
            <select value={format} onChange={e => setFormat(e.target.value)}>
              {CITATION_STYLES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Urutkan</label>
            <select value={sort} onChange={e => setSort(e.target.value)}>
              <option value="alpha">Alfabetis (A-Z)</option>
              <option value="year-desc">Tahun Terbaru</option>
              <option value="year-asc">Tahun Terlama</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Tambah DOI Manual</label>
          <div className="doi-input-row">
            <input placeholder="10.1016/j.xxx.2024.xxxxx" value={doiInput} onChange={e => setDoiInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && addByDoi()} />
            <button className="btn-primary" onClick={addByDoi} disabled={loading}>
              {loading ? <span className="spinner" /> : '+ Tambah'}
            </button>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header-row">
          <span>📋 Daftar Pustaka ({biblio.length} entri)</span>
          <div className="output-actions">
            <button className="btn-sm" onClick={copyAll}>📋 Salin Semua</button>
            <button className="btn-sm btn-danger" onClick={() => { setBiblio([]); notify('Daftar pustaka dikosongkan.', 'info'); }}>🗑️ Kosongkan</button>
          </div>
        </div>

        {biblio.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📚</div>
            <p>Belum ada referensi. Tambahkan dari Hexa-Source Reference Finder atau input DOI manual.</p>
          </div>
        ) : (
          <ol className="biblio-list">
            {getSorted().map((r, i) => (
              <li key={i} className="biblio-item">
                <div className="biblio-content">
                  <p className="biblio-formatted" dangerouslySetInnerHTML={{ __html: formatRef(r, format).replace(/\*(.*?)\*/g, '<em>$1</em>') }} />
                  <div className="biblio-meta">
                    {r.scopusIndexed && <span className="badge-scopus">🟠 Scopus</span>}
                    {r.source && <span className="badge-source">{r.source}</span>}
                  </div>
                </div>
                <button className="btn-remove" onClick={() => removeRef(r.doi)}>✕</button>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── HISTORY PAGE ─────────────────────────────────────────
// ════════════════════════════════════════════════════════
function HistoryPage({ history, setHistory, notify }: {
  history: HistoryDoc[]; setHistory: (h: HistoryDoc[]) => void; notify: (m: string, t: any) => void;
}) {
  const [selected, setSelected] = useState<HistoryDoc | null>(null);

  function deleteDoc(id: string) {
    setHistory(history.filter(d => d.id !== id));
    if (selected?.id === id) setSelected(null);
    notify('Dokumen dihapus.', 'info');
  }

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>💾 Riwayat Dokumen</h1>
        <p>Semua dokumen yang disimpan tersimpan di browser Anda. Klik kartu untuk membuka.</p>
      </div>

      {history.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">💾</div>
          <p>Belum ada riwayat. Generate dokumen pertama Anda!</p>
        </div>
      ) : (
        <div className="history-layout">
          <div className="history-list">
            {history.map(doc => (
              <div key={doc.id} className={`history-card ${selected?.id === doc.id ? 'history-card-active' : ''}`} onClick={() => setSelected(doc)}>
                <div className="history-card-header">
                  <span className="history-mode">{doc.mode}</span>
                  <button className="btn-remove" onClick={e => { e.stopPropagation(); deleteDoc(doc.id); }}>✕</button>
                </div>
                <p className="history-title">{doc.title}</p>
                <div className="history-meta">
                  <span>📅 {doc.date}</span>
                  <span>📝 {doc.words.toLocaleString()} kata</span>
                </div>
              </div>
            ))}
          </div>

          {selected && (
            <div className="history-preview">
              <div className="history-preview-header">
                <h3>{selected.title}</h3>
                <div className="output-actions">
                  <button className="btn-sm" onClick={() => { navigator.clipboard.writeText(selected.content); notify('Disalin!', 'success'); }}>📋 Salin</button>
                  <button className="btn-sm" onClick={() => {
                    const blob = new Blob([selected.content], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a'); a.href = url;
                    a.download = `${selected.title.slice(0,30)}.txt`; a.click();
                  }}>⬇️ Download</button>
                </div>
              </div>
              <div className="output-body" dangerouslySetInnerHTML={{ __html: selected.content.replace(/\n/g, '<br/>') }} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════
// ── TIPS PAGE ────────────────────────────────────────────
// ════════════════════════════════════════════════════════
function TipsPage({ stats, clock }: { stats: any; clock: string }) {
  const tips = [
    { icon:'⚡', title:'Segmented Generation Engine', content:'Mode "★ Segmented" menggunakan mesin generasi bertahap — setiap bagian dokumen digenerate secara terpisah lalu disatukan menjadi dokumen utuh. Hasil: Dokumen 8.000–15.000+ kata yang sempurna dan koheren.' },
    { icon:'🧠', title:'Panduan Pemilihan Model AI', content:'Gemini 3.1 Pro: artikel kompleks, SLR. Claude Sonnet 4.6: esai, humanize. ChatGPT o4-mini High: metodologi, STEM. Grok 4.20: empirical grounding, anti-halusinasi. DeepSeek R1: analisis logis. Llama 4 Maverick: eksperimen kreatif.' },
    { icon:'📝', title:'Prompt Terbaik untuk AI Writer', content:'Sertakan: pendekatan penelitian (kualitatif/kuantitatif), kerangka teori spesifik, konteks geografis, target jurnal, rentang kata minimal, dan variabel penelitian. Contoh: "Gunakan kerangka maqāṣid al-sharīʿah versi Auda (2008). Target Scopus Q2. Minimal 7.000 kata."' },
    { icon:'🔍', title:'Hexa-Source Reference Finder', content:'Gunakan kata kunci Bahasa Inggris. Aktifkan 🟠 Scopus untuk referensi eksklusif Q1/Q2. Aktifkan Semantic Scholar untuk 200 juta paper. Jalankan 3–4 keyword berbeda. Filter tahun 2019–2026 untuk referensi terkini. Tambahkan 20–30 referensi ke Bibliografi sebelum generate.' },
    { icon:'💬', title:'Alur Kerja Multi-Turn Writer', content:'1. Mulai dengan kerangka bab. 2. Kembangkan sub-bab dengan detail. 3. Perkuat argumentasi secara iteratif. 4. Tambahkan in-text citation. 5. Finalisasi kesimpulan. 6. Export gabungan tulisan → Download.' },
    { icon:'🎯', title:'Tips Temperatur AI', content:'0.1–0.3: Metodologi, abstrak (presisi tinggi). 0.4–0.5: Artikel akademis umum (default). 0.6–0.7: Pendahuluan, tinjauan pustaka (kreatif-analitis). 0.8–1.0: Esai, humanize (ekspresif). Untuk Scopus: gunakan 0.3–0.4.' },
    { icon:'📚', title:'Standar Sitasi & Daftar Pustaka', content:'APA 7: ilmu sosial, ekonomi Islam. Chicago Footnote: sejarah, humaniora, kajian Islam klasik. Harvard: bisnis, manajemen. IEEE: teknik, informatika. Turabian 9th: tesis/disertasi. ISNAD: kajian hadits, fiqh, tafsir.' },
    { icon:'🔧', title:'Teknik Parafrase & Humanize', content:'Parafrase Akademis: ubah struktur tanpa mengubah makna. Elaborate & Perkaya: tambah kedalaman argumentasi. Humanize: hilangkan pola AI untuk natural writing test. Formalize: ubah bahasa sehari-hari → register ilmiah. Gunakan Humanize setelah generate.' },
  ];

  return (
    <div className="page-content">
      <div className="page-hero">
        <h1>💡 Intelligence Tips & Best Practices</h1>
        <p>Panduan komprehensif untuk memaksimalkan SCHOLARIS Engine dalam menghasilkan tulisan ilmiah akademis berkualitas tinggi</p>
      </div>

      <div className="tips-grid">
        {tips.map((t, i) => (
          <div key={i} className="tip-card">
            <div className="tip-icon">{t.icon}</div>
            <h3 className="tip-title">{t.title}</h3>
            <p className="tip-content">{t.content}</p>
          </div>
        ))}
      </div>

      {/* Developer Card */}
      <div className="dev-card">
        <div className="dev-top">
          <div className="dev-avatar">👨‍🏫</div>
          <div className="dev-info">
            <h3>Dr. Iskandar, M.Ag.</h3>
            <p>Doktor Tafsir & Hermeneutika Al-Qur'an</p>
            <div className="dev-tags">
              {['Peneliti Tafsir','Digital Humanities','AI & Academic Tech','UINSI Samarinda'].map(t => (
                <span key={t} className="dev-tag">{t}</span>
              ))}
            </div>
          </div>
          <div className="dev-clock">🕐 {clock}</div>
        </div>

        <div className="dev-stats">
          {[
            { n: stats.sessions, l: 'Sesi Aktif' },
            { n: stats.words.toLocaleString(), l: 'Kata Dihasilkan' },
            { n: stats.refs, l: 'Referensi CrossRef' },
          ].map(s => (
            <div key={s.l} className="dev-stat">
              <span className="dev-stat-num">{s.n}</span>
              <span className="dev-stat-label">{s.l}</span>
            </div>
          ))}
        </div>

        <p className="dev-bio">
          <strong>SCHOLARIS</strong> dikembangkan oleh <strong>Dr. Iskandar, M.Ag.</strong>, seorang peneliti senior di bidang <strong>Tafsir dan Hermeneutika Al-Qur'an</strong> sekaligus <strong>Pemerhati Islamic Digital Humanities</strong>. Beliau adalah dosen dan peneliti pada <strong>Fakultas Ekonomi dan Bisnis Islam (FEBI), UIN Sultan Aji Muhammad Idris (UINSI) Samarinda</strong>, Kalimantan Timur.
        </p>

        <div className="dev-status-grid">
          {[
            { icon:'⚡', label:'Status Engine', value:'Aktif' },
            { icon:'🌐', label:'CrossRef API', value:'Terhubung' },
            { icon:'📅', label:'Tanggal Sistem', value: formatDate().split(',')[0] + ', ' + new Date().toLocaleDateString('id-ID') },
            { icon:'🔖', label:'Versi Engine', value:'v10.1 — Segmented' },
          ].map(s => (
            <div key={s.label} className="dev-status-item">
              <span className="dev-status-icon">{s.icon}</span>
              <div>
                <p className="dev-status-label">{s.label}</p>
                <p className="dev-status-value">{s.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="dev-contact">
          <a href="https://wa.me/6281250955443" target="_blank" rel="noreferrer" className="btn-wa">💬 WhatsApp Admin</a>
        </div>

        <p className="dev-copyright">© 2025 SCHOLARIS Digital Lab · Dr. Iskandar Zainuddin, M.Ag. · UINSI Samarinda · Kalimantan Timur, Indonesia</p>
      </div>
    </div>
  );
}
